#pragma once
#include "stdafx.h"

namespace process
{
	std::string get_system_window_dir();
	HWND get_process_window();
}