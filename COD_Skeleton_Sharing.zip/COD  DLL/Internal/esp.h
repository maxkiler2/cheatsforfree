#pragma once
#include "stdafx.h"
#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"

namespace draw
{
	void esp(ImFont* font);
}
