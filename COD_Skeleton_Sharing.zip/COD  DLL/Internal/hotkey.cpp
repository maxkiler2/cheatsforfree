#include "hotkey.h"

namespace hotkey
{
	bool Box;
	bool Eye;
	bool Bones;
	bool Names;
	bool Distance;
	bool Visible;
	int RaderZoom = 100; // 10 ~ 100
	bool Rader;
	float AimbotFov = 90.0f; // 0 ~9 999
	bool ShowFov;
	int AimPos = 0; //0 ~ 3
	int AimKey = 0; //0 ~ 2
	bool AimBot;
	bool Crosshair;
	bool Friendly;
	int ShowLimit = 600; //50 ~ 1000
}