#pragma once
#include "stdafx.h"

namespace hooks
{
	void hook_present();
	void hook_WndProc();
}