#pragma once

namespace hotkey
{
	extern bool Box;
	extern bool Eye;
	extern bool Bones;
	extern bool Names;
	extern bool Distance;
	extern bool Visible;
	extern int RaderZoom;
	extern bool Rader;
	extern float AimbotFov;
	extern bool ShowFov;
	extern int AimPos;
	extern int AimKey;
	extern bool AimBot;
	extern bool Crosshair;
	extern bool Friendly;
	extern int ShowLimit;
}