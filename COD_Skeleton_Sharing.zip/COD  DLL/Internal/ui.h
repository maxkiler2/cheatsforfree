#pragma once
#include "stdafx.h"

namespace draw
{
	void ui();
}